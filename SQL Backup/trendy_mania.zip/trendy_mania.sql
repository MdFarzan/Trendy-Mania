-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 22, 2022 at 09:15 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trendy_mania`
--

-- --------------------------------------------------------

--
-- Table structure for table `tm_admin_credentials`
--

CREATE TABLE `tm_admin_credentials` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `passkey` varchar(255) NOT NULL,
  `sign_token` varchar(255) NOT NULL,
  `creation_date` date NOT NULL DEFAULT current_timestamp(),
  `updation_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tm_admin_credentials`
--

INSERT INTO `tm_admin_credentials` (`id`, `email`, `passkey`, `sign_token`, `creation_date`, `updation_date`) VALUES
(1, 'mdfarzan776@gmail.com', '$2y$10$vOWxp3ANdXIV1urvVgfrL.vbnfBS.ltI9MYBeSO8PGC0VH9u4LTQO', '', '2022-02-22', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `tm_admin_profile`
--

CREATE TABLE `tm_admin_profile` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `contact_no` varchar(25) DEFAULT NULL,
  `avtar` varchar(255) DEFAULT NULL,
  `creation_date` date DEFAULT current_timestamp(),
  `updation_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tm_admin_profile`
--

INSERT INTO `tm_admin_profile` (`id`, `name`, `contact_no`, `avtar`, `creation_date`, `updation_date`) VALUES
(1, 'Md. Farzan', '8750611500', NULL, '2022-02-22', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tm_admin_credentials`
--
ALTER TABLE `tm_admin_credentials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tm_admin_profile`
--
ALTER TABLE `tm_admin_profile`
  ADD KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tm_admin_credentials`
--
ALTER TABLE `tm_admin_credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tm_admin_profile`
--
ALTER TABLE `tm_admin_profile`
  ADD CONSTRAINT `tm_admin_profile_ibfk_1` FOREIGN KEY (`id`) REFERENCES `tm_admin_credentials` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
